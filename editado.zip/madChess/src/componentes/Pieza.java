package componentes;

public class Pieza {

}
